package RadiatorStatePattern.view;

import RadiatorStatePattern.Core.ViewModelFactory;
public interface ViewController
{
  void init(ViewModelFactory vmf);
}
