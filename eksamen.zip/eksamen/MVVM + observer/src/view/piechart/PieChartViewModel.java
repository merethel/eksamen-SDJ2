package view.piechart;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.DataModel;

import java.beans.PropertyChangeEvent;

public class PieChartViewModel
{

  private DoubleProperty x;
  private DoubleProperty y;
  private DoubleProperty z;
  private StringProperty updateTimeStamp;

  public PieChartViewModel(DataModel model)
  {
    updateTimeStamp = new SimpleStringProperty("Last update: ");
    x = new SimpleDoubleProperty();
    y = new SimpleDoubleProperty();
    z = new SimpleDoubleProperty();
    model.addPropertyChangeListener("Data", evt -> updatePieChart(evt));
    model.addPropertyChangeListener("TimeUpdate", evt -> timeStampUpdated(evt));
  }

  private void updatePieChart(PropertyChangeEvent event)
  {
    Platform.runLater(() -> {
      double[] values = (double[]) event.getNewValue();
      x.setValue(values[0]);
      y.setValue(values[1]);
      z.setValue(values[2]);
    });
  }

  private void timeStampUpdated(PropertyChangeEvent event)
  {
    Platform.runLater(() -> {
      updateTimeStamp.setValue("Last updated: " + event.getNewValue());
    });
  }

  public DoubleProperty xProperty()
  {
    return x;
  }

  public DoubleProperty yProperty()
  {
    return y;
  }

  public DoubleProperty zProperty()
  {
    return z;
  }

  public StringProperty updateTimeStampProperty()
  {
    return updateTimeStamp;
  }
}
