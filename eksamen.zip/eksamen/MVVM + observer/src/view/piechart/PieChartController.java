package view.piechart;

import core.ViewModelFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import view.ViewController;

public class PieChartController implements ViewController
{

    @FXML
    Label eventLabel;

    @FXML
    PieChart pieChart;

    private PieChartViewModel pieChartViewModel;

    private PieChart.Data x = new PieChart.Data("X", 0);
    private PieChart.Data y = new PieChart.Data("Y", 0);
    private PieChart.Data z = new PieChart.Data("Z", 0);

    public void init(ViewModelFactory vmf) {
        this.pieChartViewModel = vmf.getPieChartViewModel();

        x.pieValueProperty().bind(pieChartViewModel.xProperty());
        y.pieValueProperty().bind(pieChartViewModel.yProperty());
        z.pieValueProperty().bind(pieChartViewModel.zProperty());

        eventLabel.textProperty().bind(pieChartViewModel.updateTimeStampProperty());

        ObservableList<PieChart.Data> datas = FXCollections.observableArrayList(x, y, z);
        pieChart.setData(datas);
    }

}
