package view.barchart;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import model.DataModel;

import java.beans.PropertyChangeEvent;

public class BarChartViewModel
{

  private DoubleProperty x;
  private DoubleProperty y;
  private DoubleProperty z;
  private StringProperty updateTimeStamp;

  public BarChartViewModel(DataModel model)
  {
    updateTimeStamp = new SimpleStringProperty("Last update: ");
    x = new SimpleDoubleProperty();
    y = new SimpleDoubleProperty();
    z = new SimpleDoubleProperty();
    model.addPropertyChangeListener("Data", evt -> updateBarChart(evt));
    model.addPropertyChangeListener("TimeUpdate", evt -> timeStampUpdated(evt));
  }

  private void updateBarChart(PropertyChangeEvent event)
  {
    Platform.runLater(() -> {
      double[] values = (double[]) event.getNewValue();
      x.setValue(values[0]);
      y.setValue(values[1]);
      z.setValue(values[2]);
    });
  }

  private void timeStampUpdated(PropertyChangeEvent event)
  {
    Platform.runLater(() -> {
      updateTimeStamp.setValue("Last updated: " + event.getNewValue());
    });
  }

  public ObservableValue xProperty()
  {
    return x;
  }

  public ObservableValue yProperty()
  {
    return y;
  }

  public ObservableValue zProperty()  { return z; }

  public StringProperty updateTimeStampProperty()
  {
    return updateTimeStamp;
  }

}
