package view.barchart;

import core.ViewModelFactory;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import view.ViewController;

public class BarChartController implements ViewController
{
  @FXML
  private BarChart<String, Double> barChart;
  @FXML
  private Label eventLabel;

  private BarChartViewModel barChartViewModel;

  private XYChart.Data<String, Double> x = new XYChart.Data<String, Double>("X", 0.0);
  private XYChart.Data<String, Double> y = new XYChart.Data<String, Double>("Y", 0.0);
  private XYChart.Data<String, Double> z = new XYChart.Data<String, Double>("Z", 0.0);

  public void init(ViewModelFactory vmf)
  {
    barChartViewModel = vmf.getBarChartViewModel();

    x.YValueProperty().bind(barChartViewModel.xProperty());
    y.YValueProperty().bind(barChartViewModel.yProperty());
    z.YValueProperty().bind(barChartViewModel.zProperty());
    eventLabel.textProperty().bind(barChartViewModel.updateTimeStampProperty());

    XYChart.Series xSeries = new XYChart.Series();
    xSeries.setName("X");
    xSeries.getData().add(x);
    barChart.getData().add(xSeries);

    XYChart.Series ySeries = new XYChart.Series();
    ySeries.setName("Y");
    ySeries.getData().add(y);
    barChart.getData().add(ySeries);

    XYChart.Series zSeries = new XYChart.Series();
    zSeries.setName("Z");
    zSeries.getData().add(z);
    barChart.getData().add(zSeries);
  }

}
