package view.text;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.DataModel;

import java.beans.PropertyChangeEvent;

public class TextViewModel
{

  private StringProperty x;
  private StringProperty y;
  private StringProperty z;
  private StringProperty updateTimeStamp;

  private DataModel model;

  public TextViewModel(DataModel model)
  {
    this.model = model;

    updateTimeStamp = new SimpleStringProperty();
    x = new SimpleStringProperty();
    y = new SimpleStringProperty();
    z = new SimpleStringProperty();
    model.addPropertyChangeListener("Data", evt -> updateTextFields(evt));
    model.addPropertyChangeListener("TimeUpdate", evt -> timeStampUpdated(evt));
  }

  public void updateTextFields(PropertyChangeEvent event)
  {
    double[] values = (double[]) event.getNewValue();
    x.setValue(Double.toString(values[0]));
    y.setValue(Double.toString(values[1]));
    z.setValue(Double.toString(values[2]));
  }

  private void timeStampUpdated(PropertyChangeEvent event)
  {
    Platform.runLater(() -> {
      updateTimeStamp.setValue("Last updated: " + event.getNewValue());
    });
  }

  public void saveChanges()
  {
    double doubleX = Double.parseDouble(x.getValue());
    double doubleY = Double.parseDouble(y.getValue());
    double doubleZ = Double.parseDouble(z.getValue());
    model.saveData(doubleX, doubleY, doubleZ);
  }

  public StringProperty xProperty()
  {
    return x;
  }

  public StringProperty yProperty()
  {
    return y;
  }

  public StringProperty zProperty()
  {
    return z;
  }

  public StringProperty updateTimeStampProperty() {
    return updateTimeStamp;
  }


}
