package view.text;

import core.ViewModelFactory;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import view.ViewController;

public class TextController implements ViewController
{
  @FXML
  private Label eventLabel;

  @FXML
  private TextField xTextField;

  @FXML
  private TextField yTextField;

  @FXML
  private TextField zTextField;

  private TextViewModel textViewModel;

  public void init(ViewModelFactory vmf)
  {
    this.textViewModel = vmf.getTextVM();
    eventLabel.textProperty().bind(textViewModel.updateTimeStampProperty());
    xTextField.textProperty().bindBidirectional(textViewModel.xProperty());
    yTextField.textProperty().bindBidirectional(textViewModel.yProperty());
    zTextField.textProperty().bindBidirectional(textViewModel.zProperty());
  }

 @FXML
  public void onSaveButton()
 {
   textViewModel.saveChanges();
 }

}
