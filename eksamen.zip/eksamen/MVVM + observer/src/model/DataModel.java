package model;

import util.PropertyChangeSubject;

public interface DataModel extends PropertyChangeSubject
{

    void saveData(double doubleX, double doubleY, double doubleZ);

}
