package model;

import util.PropertyChangeSubject;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class DataModelManager implements DataModel, PropertyChangeSubject
{
    private double x;
    private double y;
    private double z;
    private String lastUpdate;

    private Random random = new Random();
    private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    @Override public void saveData(double doubleX, double doubleY, double doubleZ)
    {
        x = doubleX;
        y = doubleY;
        z = doubleZ;
        propertyChangeSupport.firePropertyChange("Data", null, new double[]{x,y,z});
    }

    public void recalculateData() {
        int first = random.nextInt(100)+1;
        int second = random.nextInt(100)+1;
        int bottom = Math.min(first, second);
        int top = Math.max(first, second);

        x = bottom;
        y = top - bottom;
        z = 100 - top;
        double[] newValues = {x,y,z};
        propertyChangeSupport.firePropertyChange("Data", null, newValues);
        calTimeStamp();
    }

    private void calTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("HH:mm:ss");
        Date now = new Date();
        String strDate = sdfDate.format(now);
        propertyChangeSupport.firePropertyChange("TimeUpdate", lastUpdate, strDate);
        lastUpdate = strDate;
    }

    @Override public void addPropertyChangeListener(PropertyChangeListener listener)
    {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    @Override public void addPropertyChangeListener(String name, PropertyChangeListener listener)
    {
        if(name == null)
            addPropertyChangeListener(listener);
        else
            propertyChangeSupport.addPropertyChangeListener(name, listener);
    }

    @Override public void removePropertyChangeListener(PropertyChangeListener listener)
    {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    @Override public void removePropertyChangeListener(String name, PropertyChangeListener listener)
    {
        if(name == null)
            propertyChangeSupport.removePropertyChangeListener(listener);
        else
            propertyChangeSupport.removePropertyChangeListener(name, listener);
    }
}
