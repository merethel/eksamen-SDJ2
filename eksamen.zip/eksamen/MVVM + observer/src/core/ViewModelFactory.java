package core;
import view.barchart.BarChartViewModel;
import view.piechart.PieChartViewModel;
import view.text.TextViewModel;

public class ViewModelFactory
{
  private static final ViewModelFactory instance = new ViewModelFactory();
  private PieChartViewModel pieChartVM;
  private BarChartViewModel barChartVM;
  private TextViewModel textVM;



  private ViewModelFactory() {
  }

  public static ViewModelFactory getInstance(){
    return instance;
  }


  public PieChartViewModel getPieChartViewModel()
  {
    if (pieChartVM == null)
      pieChartVM = new PieChartViewModel(ModelFactory.getInstance().getModel());
    return pieChartVM;
  }

  public BarChartViewModel getBarChartViewModel()
  {
    if (barChartVM == null)
      barChartVM = new BarChartViewModel(ModelFactory.getInstance().getModel());
    return barChartVM;
  }

  public TextViewModel getTextVM()
  {
    if (textVM == null)
      textVM = new TextViewModel(ModelFactory.getInstance().getModel());
    return textVM;
  }
}
