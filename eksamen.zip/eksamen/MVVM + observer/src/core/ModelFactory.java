package core;

import model.DataModel;
import model.DataModelManager;

public class ModelFactory
{
  private static final ModelFactory instance = new ModelFactory();
  private volatile DataModel model;

  private ModelFactory()
  {
  }

  public static ModelFactory getInstance(){
    return instance;
  }

  public DataModel getModel()
  {
    if (model == null) {
      synchronized (this) {
        if (model == null) {
          model = new DataModelManager();
        }
      }
    }
    return model;
  }

}
