package core;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ViewHandler
{
  private static final ViewHandler instance = new ViewHandler();
  private Stage stage1;
  private Stage stage2;
  private Stage stage3;

  private ViewHandler() {
  }

  public static ViewHandler getInstance(){
    return instance;
  }

  public void start() throws IOException
  {
    stage1 = new Stage();
    ViewFactory.init(stage1);
    stage1.centerOnScreen();
    stage2 = new Stage();
    ViewFactory.init(stage2);
    stage2.centerOnScreen();
    stage3 = new Stage();
    ViewFactory.init(stage3);
    stage3.centerOnScreen();
    openPieChartView();
    openTextView();
    openBarChartView();
  }

  public void openPieChartView() {
    Scene piechart = ViewFactory.getScene("piechart");
    stage1.setScene(piechart);
    stage1.centerOnScreen();
    stage1.show();
  }

  public void openBarChartView() {
    Scene barchart = ViewFactory.getScene("barchart");
    stage2.setScene(barchart);
    stage2.centerOnScreen();
    stage2.show();
  }

  public void openTextView() {
    Scene text = ViewFactory.getScene("text");
    stage3.setScene(text);
    stage3.centerOnScreen();
    stage3.show();
  }
}
