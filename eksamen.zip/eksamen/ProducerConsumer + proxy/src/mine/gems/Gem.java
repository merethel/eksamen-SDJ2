package mine.gems;

public interface Gem
{
  String getName();
  int getValue();
  String toString();
}
