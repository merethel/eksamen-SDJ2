package server.Model;

public interface Action
{
  int operation(int number);
}
