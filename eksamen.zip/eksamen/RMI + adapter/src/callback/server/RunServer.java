package callback.server;

import callback.shared.UpperCaseServer;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RunServer
{
  public static void main(String[] args)
      throws RemoteException, AlreadyBoundException
  {
    UpperCaseServer server = new RMIServerImpl();
    Registry registry = LocateRegistry.createRegistry(1099);
    registry.bind("server", server); /*We put the server into the registry - client must
    use the same name, to access this server object*/
    System.out.println("Server started...");
  }
}
